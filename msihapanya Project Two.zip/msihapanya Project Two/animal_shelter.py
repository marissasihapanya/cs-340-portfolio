from pymongo import MongoClient
from bson.objectid import ObjectId
# Setup the Jupyter version of Dash
from jupyter_dash import JupyterDash

# Configure the necessary Python module imports for dashboard components
import dash_leaflet as dl
from dash import dcc
from dash import html
import plotly.express as px
from dash import dash_table
from dash.dependencies import Input, Output, State
import base64

# Configure OS routines
import os

# Configure the plotting routines
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'password'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31969
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        self.username = username
        self.password = password

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary            
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            data_to_return = list(self.database.animals.find(data))
            for doc in data_to_return:
                doc['_id'] = str(doc['_id'])
            result = list(data_to_return)
            return result
        else:
            raise Exception("Can't read the document!")

    
# Update
    def update(self, data, update_values):
        if data is not None:
            result = self.database.animals.update_one(data, {'$set': update_values})
            # Rest of the code to update
            # Code to update values of a dictionary by key
            # return the amount of objects updated
            updated = result.matched_count
            return updated
        else:
            raise Exception("Can't update the document")
            
# Delete
    def delete(self, data):
        if data is not None:
            return (self.database.animals.delete_many(data)).deleted_count
        else:
            raise Exception("Can't delete the document")
            
        
